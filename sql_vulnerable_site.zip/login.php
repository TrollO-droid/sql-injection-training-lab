<?php
include("config.php");

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM users WHERE id = '$id'";
    $result = mysqli_query($conn, $query);
    if ($row = mysqli_fetch_assoc($result)) {
        echo "<h3>Kullanıcı: " . $row['username'] . "</h3>";
        echo "<p>Parola: " . $row['password'] . "</p>";
    } else {
        echo "Kullanıcı bulunamadı.";
    }
} else {
    echo "<p>Lütfen URL'ye ?id=1 gibi bir parametre ekleyin.</p>";
}
?>
