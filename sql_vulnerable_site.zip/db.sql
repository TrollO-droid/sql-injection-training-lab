
CREATE DATABASE IF NOT EXISTS ctf;
USE ctf;

CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50),
    password VARCHAR(100)
);

INSERT INTO users (username, password) VALUES
('admin', '$2y$10$uQsD1lYH8EXAMPLEXyoBKuJMXeF7eZ9GaKZAj9srjTVR8aKmjVq9i');
