<?php
echo "<h2>Hoşgeldiniz</h2>";
echo "<p>Giriş için <a href='login.php'>tıklayın</a></p>";
?>
