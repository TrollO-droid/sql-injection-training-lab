<?php
$conn = mysqli_connect("localhost", "root", "", "ctf");
if (!$conn) {
    die("Bağlantı hatası: " . mysqli_connect_error());
}
?>
